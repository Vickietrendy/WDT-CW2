import '../css/reset.css';
import '../css/utility.css';
import '../css/main.css';

// const navBtn = document.querySelector('.mobile-nav-toggle');
// const nav = document.querySelector('.nav');
// const closeBtn = document.querySelector('.close-nav');

// navBtn.addEventListener('click', ()=>{
//     nav.classList.add('nav-open');
// })

// closeBtn.addEventListener('click', () => {
//     nav.classList.remove('nav-open');
// })
