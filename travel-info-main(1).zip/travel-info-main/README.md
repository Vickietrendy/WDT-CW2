<!-- https://www.behance.net/gallery/160699941/Earth-Guardian-Landing-Page?tracking_source=search_projects%7Cabout+us+page -->

To start server on local machine
- Run `yarn start`
